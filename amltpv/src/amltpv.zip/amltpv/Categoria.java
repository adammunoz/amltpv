/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package amltpv;

/**
 *
 * @author adam
 */
public class Categoria {
    private String nombre;
    public Categoria(String nombre){
        this.nombre = nombre;
    }
    public String getNombre(){
        return nombre;
    }
}
