/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package amltpv;

/**
 *
 * @author adam
 */
public interface LoggedDialog {
    public void setLoggedUser(String user);
}
